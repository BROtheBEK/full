import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CartSidebar({ isOpen, onClose }: CartSidebarProps) {
  const { items, updateQuantity, removeItem, clearCart, total } = useCart();
  const { user, openLoginModal } = useAuth();
  const { t } = useLanguage();
  const { toast } = useToast();
  const [showCheckout, setShowCheckout] = useState(false);
  const [orderData, setOrderData] = useState({
    address: "",
    paymentMethod: "cash" as "cash" | "card" | "humo" | "uzcard" | "click" | "payme",
    coordinates: null as { lat: number; lng: number } | null,
  });

  const createOrderMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/orders", data);
    },
    onSuccess: () => {
      clearCart();
      setShowCheckout(false);
      onClose();
      toast({ 
        title: t('orderPlaced'), 
        description: t('orderPlacedDesc') 
      });
    },
    onError: () => {
      toast({ 
        title: t('error'), 
        description: t('orderError'), 
        variant: "destructive" 
      });
    },
  });

  const handleCheckout = () => {
    if (!user) {
      openLoginModal();
      return;
    }
    setShowCheckout(true);
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!orderData.address.trim()) {
      toast({ 
        title: t('error'), 
        description: t('addressRequired'), 
        variant: "destructive" 
      });
      return;
    }

    // Check if non-cash payment is selected
    if (orderData.paymentMethod !== "cash") {
      // Redirect to payment processing
      toast({
        title: "To'lovga o'tkazilmoqda",
        description: `${orderData.paymentMethod.toUpperCase()} orqali to'lov qilish uchun yo'naltirilmoqda...`
      });
      
      // Simulate payment processing (in real app, this would redirect to payment gateway)
      setTimeout(() => {
        toast({
          title: "To'lov sahifasi",
          description: `${orderData.paymentMethod.toUpperCase()} to'lov tizimiga ulanish uchun buyurtmani tasdiqlang`,
        });
      }, 1000);
      
      return;
    }

    const orderItems = items.map(item => ({
      productId: item.id,
      quantity: item.quantity,
      price: (item.price * item.quantity).toString(),
    }));

    createOrderMutation.mutate({
      userId: user?.id,
      items: orderItems,
      totalAmount: total.toString(),
      deliveryAddress: orderData.address,
      paymentMethod: orderData.paymentMethod,
      coordinates: orderData.coordinates,
    });
  };

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed inset-y-0 right-0 w-full sm:w-96 bg-white shadow-xl z-50 transform transition-transform duration-300 ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}>
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-6 border-b">
            <h2 className="text-xl font-semibold text-neutral-900">
              {showCheckout ? t('checkout') : t('cart')}
            </h2>
            <button 
              onClick={onClose}
              className="text-neutral-400 hover:text-neutral-600"
            >
              <i className="fas fa-times text-xl"></i>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            {!showCheckout ? (
              // Cart Items View
              <>
                {items.length === 0 ? (
                  <div className="text-center py-12">
                    <i className="fas fa-shopping-cart text-4xl text-neutral-300 mb-4"></i>
                    <p className="text-neutral-500">{t('cartEmpty')}</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {items.map((item) => (
                      <Card key={item.id}>
                        <CardContent className="flex items-center space-x-4 p-4">
                          {item.image && (
                            <img 
                              src={item.image} 
                              alt={item.name}
                              className="w-16 h-16 object-cover rounded-lg" 
                            />
                          )}
                          <div className="flex-1">
                            <h3 className="font-semibold text-neutral-900">{item.name}</h3>
                            <p className="text-primary font-bold">
                              {item.price.toLocaleString()} {t('currency')}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <button 
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="w-8 h-8 rounded-full border border-neutral-200 flex items-center justify-center"
                            >
                              <i className="fas fa-minus text-xs"></i>
                            </button>
                            <span className="font-medium">{item.quantity}</span>
                            <button 
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="w-8 h-8 rounded-full border border-neutral-200 flex items-center justify-center"
                            >
                              <i className="fas fa-plus text-xs"></i>
                            </button>
                            <button 
                              onClick={() => removeItem(item.id)}
                              className="ml-2 text-red-500 hover:text-red-700"
                            >
                              <i className="fas fa-trash text-sm"></i>
                            </button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </>
            ) : (
              // Checkout Form
              <form onSubmit={handlePlaceOrder} className="space-y-6">
                <div>
                  <Label htmlFor="address">{t('deliveryAddress')}</Label>
                  <Textarea
                    id="address"
                    value={orderData.address}
                    onChange={(e) => setOrderData(prev => ({ ...prev, address: e.target.value }))}
                    placeholder="Masalan: Toshkent shahar, Olmazor tumani, Buyuk Ipak Yo'li ko'chasi, 123-uy"
                    required
                    rows={3}
                  />
                  <p className="text-sm text-neutral-500 mt-1">
                    Iltimos, to'liq manzilni ko'rsating (viloyat, tuman, ko'cha, uy raqami)
                  </p>
                </div>

                <div>
                  <Label htmlFor="phone">{t('phoneNumber')}</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={user?.phone || ""}
                    disabled
                    className="bg-neutral-50"
                  />
                </div>

                <div>
                  <Label htmlFor="notes">Qo'shimcha ma'lumot (ixtiyoriy)</Label>
                  <Textarea
                    id="notes"
                    placeholder="Binoning raqami, qavat, kvartira raqami yoki boshqa ma'lumotlar"
                    rows={2}
                  />
                </div>

                <div>
                  <Label>Joylashuvni belgilash</Label>
                  <div className="space-y-3">
                    <Button 
                      type="button"
                      variant="outline" 
                      onClick={() => {
                        if (navigator.geolocation) {
                          navigator.geolocation.getCurrentPosition(
                            (position) => {
                              setOrderData(prev => ({
                                ...prev,
                                coordinates: {
                                  lat: position.coords.latitude,
                                  lng: position.coords.longitude
                                }
                              }));
                              toast({
                                title: "Joylashuv belgilandi",
                                description: "Sizning joylashuvingiz muvaffaqiyatli belgilandi"
                              });
                            },
                            (error) => {
                              toast({
                                title: "Xatolik",
                                description: "Joylashuvni aniqlab bo'lmadi",
                                variant: "destructive"
                              });
                            }
                          );
                        }
                      }}
                      className="w-full"
                    >
                      <i className="fas fa-map-marker-alt mr-2"></i>
                      {orderData.coordinates ? "Joylashuv belgilangan" : "Joylashuvni aniqlash"}
                    </Button>
                    {orderData.coordinates && (
                      <p className="text-sm text-green-600">
                        <i className="fas fa-check-circle mr-1"></i>
                        Koordinatalar: {orderData.coordinates.lat.toFixed(6)}, {orderData.coordinates.lng.toFixed(6)}
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <Label>{t('paymentMethod')}</Label>
                  <RadioGroup 
                    value={orderData.paymentMethod} 
                    onValueChange={(value) => setOrderData(prev => ({ ...prev, paymentMethod: value as any }))}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="cash" id="cash" />
                      <Label htmlFor="cash" className="flex items-center">
                        <i className="fas fa-money-bill-wave mr-2 text-green-600"></i>
                        Naqd pul
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="humo" id="humo" />
                      <Label htmlFor="humo" className="flex items-center">
                        <i className="fas fa-credit-card mr-2 text-blue-600"></i>
                        Humo
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="uzcard" id="uzcard" />
                      <Label htmlFor="uzcard" className="flex items-center">
                        <i className="fas fa-credit-card mr-2 text-purple-600"></i>
                        UzCard
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="click" id="click" />
                      <Label htmlFor="click" className="flex items-center">
                        <i className="fas fa-mobile-alt mr-2 text-orange-600"></i>
                        Click
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="payme" id="payme" />
                      <Label htmlFor="payme" className="flex items-center">
                        <i className="fas fa-wallet mr-2 text-cyan-600"></i>
                        Payme
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="border-t pt-4">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-lg font-semibold">{t('total')}:</span>
                    <span className="text-2xl font-bold text-primary">
                      {total.toLocaleString()} {t('currency')}
                    </span>
                  </div>
                </div>

                <div className="flex space-x-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowCheckout(false)}
                    className="flex-1"
                  >
                    {t('back')}
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createOrderMutation.isPending}
                    className="flex-1 bg-secondary hover:bg-green-600"
                  >
                    {createOrderMutation.isPending ? t('placing') : t('placeOrder')}
                  </Button>
                </div>
              </form>
            )}
          </div>

          {!showCheckout && items.length > 0 && (
            <div className="border-t p-6">
              <div className="flex justify-between items-center mb-4">
                <span className="text-lg font-semibold text-neutral-900">{t('total')}:</span>
                <span className="text-2xl font-bold text-primary">
                  {total.toLocaleString()} {t('currency')}
                </span>
              </div>
              <Button 
                onClick={handleCheckout}
                className="w-full bg-secondary hover:bg-green-600 text-white py-3 font-semibold"
              >
                {t('checkout')}
              </Button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
