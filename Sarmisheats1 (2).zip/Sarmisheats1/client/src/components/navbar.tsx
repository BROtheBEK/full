import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLanguage } from "@/hooks/use-language";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { Link } from "wouter";
import logoPath from "@assets/logo_1748530812051.png";

interface NavbarProps {
  onCartClick: () => void;
}

export default function Navbar({ onCartClick }: NavbarProps) {
  const { language, setLanguage, t } = useLanguage();
  const { user, openLoginModal, openSignupModal, logout } = useAuth();
  const { items } = useCart();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-3 cursor-pointer">
              <img 
                src={logoPath} 
                alt="Sarmish Eats" 
                className="w-10 h-10 object-contain"
              />
              <span className="text-xl font-bold text-neutral-900">Sarmish Eats</span>
            </div>
          </Link>

          {/* Navigation Links - Desktop */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              {t('home')}
            </a>
            <a href="#products" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              {t('products')}
            </a>
            <Link href="/news" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              {t('news')}
            </Link>
            <Link href="/contact" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              {t('contact')}
            </Link>
          </div>

          {/* Right Side Controls */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            {/* Language Selector - Hidden on mobile */}
            <div className="hidden sm:block">
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-16 sm:w-20 border-neutral-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="uz">🇺🇿 UZ</SelectItem>
                  <SelectItem value="ru">🇷🇺 RU</SelectItem>
                  <SelectItem value="en">🇬🇧 EN</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Cart Icon */}
            <button 
              onClick={onCartClick}
              className="relative p-2 text-neutral-700 hover:text-primary transition-colors"
            >
              <i className="fas fa-shopping-cart text-lg sm:text-xl"></i>
              {itemCount > 0 && (
                <Badge className="absolute -top-1 -right-1 bg-accent text-white min-w-5 h-5 flex items-center justify-center text-xs">
                  {itemCount}
                </Badge>
              )}
            </button>

            {/* Authentication Buttons - Desktop */}
            {user ? (
              <div className="hidden md:flex items-center space-x-3">
                <span className="text-neutral-700 text-sm lg:text-base">
                  {t('hello')}, {user.firstName || user.phone}
                </span>
                {user.role === "admin" && (
                  <Link href="/admin">
                    <Button size="sm" variant="outline">Admin</Button>
                  </Link>
                )}
                {user.role === "delivery" && (
                  <Link href="/delivery">
                    <Button size="sm" variant="outline">Yetkazish</Button>
                  </Link>
                )}
                {user.role === "operator" && (
                  <Link href="/operator">
                    <Button size="sm" variant="outline">Operator</Button>
                  </Link>
                )}
                <Button size="sm" variant="ghost" onClick={logout}>
                  {t('logout')}
                </Button>
              </div>
            ) : (
              <div className="hidden md:flex items-center space-x-2">
                <Button size="sm" variant="ghost" onClick={openLoginModal}>
                  {t('login')}
                </Button>
                <Button size="sm" onClick={openSignupModal}>
                  {t('signup')}
                </Button>
              </div>
            )}

            {/* User Icon for Mobile */}
            {user && (
              <div className="md:hidden">
                <button className="p-2 text-neutral-700 hover:text-primary transition-colors">
                  <i className="fas fa-user text-lg"></i>
                </button>
              </div>
            )}

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2 text-neutral-700 hover:text-primary transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <i className="fas fa-bars text-lg"></i>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-neutral-200 py-4 space-y-3">
            <a href="#" className="block py-2 px-2 text-neutral-700 hover:text-primary transition-colors font-medium">
              {t('home')}
            </a>
            <a href="#products" className="block py-2 px-2 text-neutral-700 hover:text-primary transition-colors font-medium">
              {t('products')}
            </a>
            <a href="#" className="block py-2 px-2 text-neutral-700 hover:text-primary transition-colors font-medium">
              {t('news')}
            </a>
            <a href="#" className="block py-2 px-2 text-neutral-700 hover:text-primary transition-colors font-medium">
              {t('contact')}
            </a>
            
            {/* Language Selector for Mobile */}
            <div className="py-2 px-2">
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-full border-neutral-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="uz">🇺🇿 UZ</SelectItem>
                  <SelectItem value="ru">🇷🇺 RU</SelectItem>
                  <SelectItem value="en">🇬🇧 EN</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Authentication for Mobile */}
            <div className="border-t border-neutral-200 pt-3 space-y-2">
              {user ? (
                <div className="px-2 space-y-2">
                  <div className="text-neutral-700 font-medium">
                    {t('hello')}, {user.firstName || user.phone}
                  </div>
                  {user.role === "admin" && (
                    <Link href="/admin">
                      <Button size="sm" variant="outline" className="w-full justify-start">
                        <i className="fas fa-cog mr-2"></i>
                        Admin Panel
                      </Button>
                    </Link>
                  )}
                  {user.role === "delivery" && (
                    <Link href="/delivery">
                      <Button size="sm" variant="outline" className="w-full justify-start">
                        <i className="fas fa-truck mr-2"></i>
                        Yetkazish
                      </Button>
                    </Link>
                  )}
                  {user.role === "operator" && (
                    <Link href="/operator">
                      <Button size="sm" variant="outline" className="w-full justify-start">
                        <i className="fas fa-headset mr-2"></i>
                        Operator
                      </Button>
                    </Link>
                  )}
                  <Button size="sm" variant="ghost" onClick={logout} className="w-full justify-start">
                    <i className="fas fa-sign-out-alt mr-2"></i>
                    {t('logout')}
                  </Button>
                </div>
              ) : (
                <div className="px-2 space-y-2">
                  <Button variant="ghost" onClick={openLoginModal} className="w-full justify-start">
                    <i className="fas fa-sign-in-alt mr-2"></i>
                    {t('login')}
                  </Button>
                  <Button onClick={openSignupModal} className="w-full justify-start">
                    <i className="fas fa-user-plus mr-2"></i>
                    {t('signup')}
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
