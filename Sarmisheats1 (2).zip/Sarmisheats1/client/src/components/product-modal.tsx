import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ProductModalProps {
  productId: number;
  onClose: () => void;
}

export default function ProductModal({ productId, onClose }: ProductModalProps) {
  const [quantity, setQuantity] = useState(1);
  const [comment, setComment] = useState("");
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  
  const { addItem } = useCart();
  const { user } = useAuth();
  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: product } = useQuery({
    queryKey: ["/api/products", productId],
  });

  const { data: comments = [] } = useQuery({
    queryKey: ["/api/products", productId, "comments"],
  });

  const createCommentMutation = useMutation({
    mutationFn: async ({ content, userId }: { content: string; userId: number }) => {
      return apiRequest("POST", `/api/products/${productId}/comments`, { content, userId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "comments"] });
      setComment("");
      toast({ title: t('commentAdded'), description: t('commentAddedDesc') });
    },
  });

  const handleAddToCart = () => {
    if (!product) return;

    addItem({
      id: product.id,
      name: product.name,
      price: parseFloat(product.price),
      quantity,
      image: product.images?.[0] || "",
    });

    // Add comment if provided
    if (comment.trim() && user) {
      createCommentMutation.mutate({ content: comment, userId: user.id });
    }

    toast({
      title: t('addedToCart'),
      description: `${quantity} x ${product.name} ${t('addedToCartDesc')}`,
    });

    onClose();
  };

  if (!product) {
    return null;
  }

  const images = product.images || [];
  const currentImage = images[selectedImageIndex];

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-screen overflow-y-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Product Images */}
          <div className="space-y-4">
            {currentImage && (
              <div className="aspect-square bg-neutral-100 rounded-lg overflow-hidden">
                <img 
                  src={currentImage} 
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            
            {images.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImageIndex(index)}
                    className={`aspect-square bg-neutral-100 rounded border-2 overflow-hidden ${
                      index === selectedImageIndex ? 'border-primary' : 'border-transparent'
                    }`}
                  >
                    <img 
                      src={image} 
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-neutral-900 mb-4">{product.name}</h1>
              <p className="text-neutral-600 mb-6">{product.description}</p>
              <div className="flex items-center space-x-2 mb-4">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <i 
                      key={star}
                      className={`fas fa-star ${star <= 4 ? 'text-yellow-400' : 'text-neutral-300'}`}
                    />
                  ))}
                </div>
                <span className="text-neutral-600">(12 baho)</span>
              </div>
              <div className="text-3xl font-bold text-primary">
                {Number(product.price).toLocaleString()} so'm
              </div>
            </div>

            {/* Quantity Selector */}
            <div>
              <Label className="text-sm font-medium text-neutral-700 mb-2 block">
                {t('quantity')}
              </Label>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 rounded-full border border-neutral-200 flex items-center justify-center hover:bg-neutral-50"
                  >
                    <i className="fas fa-minus"></i>
                  </button>
                  <span className="text-xl font-medium w-12 text-center">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 rounded-full border border-neutral-200 flex items-center justify-center hover:bg-neutral-50"
                  >
                    <i className="fas fa-plus"></i>
                  </button>
                </div>
              </div>
            </div>

            {/* Comment Section */}
            {user && (
              <div>
                <Label htmlFor="comment" className="text-sm font-medium text-neutral-700 mb-2 block">
                  {t('leaveComment')}
                </Label>
                <Textarea 
                  id="comment"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder={t('commentPlaceholder')}
                  rows={3}
                />
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <Button 
                onClick={handleAddToCart}
                className="flex-1 bg-secondary hover:bg-green-600 text-white py-3 text-lg"
              >
                <i className="fas fa-plus mr-2"></i>
                {t('addToCart')}
              </Button>
              <Button 
                variant="outline"
                onClick={onClose}
                className="px-6 py-3"
              >
                {t('cancel')}
              </Button>
            </div>

            {/* Comments Display */}
            {comments.length > 0 && (
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">{t('customerComments')}</h3>
                <div className="space-y-4 max-h-40 overflow-y-auto">
                  {comments.map((comment: any) => (
                    <div key={comment.id} className="bg-neutral-50 p-3 rounded-lg">
                      <p className="text-neutral-700">{comment.content}</p>
                      <p className="text-sm text-neutral-500 mt-1">
                        {new Date(comment.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
