export const translations = {
  uz: {
    // Navigation
    home: "Bosh sahifa",
    products: "Mahsulotlar",
    news: "Yangiliklar",
    contact: "Bog'lanish",
    login: "Kirish",
    signup: "Ro'yxatdan o'tish",
    logout: "Chiqish",
    hello: "Salom",
    
    // Homepage
    fastAndDelicious: "Tez va Mazali",
    uzbekNationalDishes: "O'zbek milliy taomlarini uyingizgacha yetkazib beramiz",
    orderNow: "Buyurtma berish",
    newTaste: "Yangi Ta'm",
    freshDailyMeals: "Har kuni yangi va sifatli taomlar tayyorlaymiz",
    viewMore: "Ko'proq ko'rish",
    in30Minutes: "30 Daqiqada",
    deliveryPromise: "Barcha buyurtmalarni 30 daqiqa ichida yetkazamiz",
    popularDishes: "Mashhur Taomlar",
    selectDeliciousDishes: "Eng sara va mazali taomlarimizni tanlang",
    
    // Features
    whyChooseUs: "Nega aynan biz?",
    ourAdvantages: "Bizning afzalliklarimiz",
    fastDelivery: "Tez yetkazish",
    fastDeliveryDesc: "30 daqiqa ichida uyingizgacha yetkazib beramiz",
    qualityFood: "Sifatli taomlar",
    qualityFoodDesc: "Faqat yangi va sifatli mahsulotlardan tayyorlaymiz",
    "24_7Service": "24/7 xizmat",
    "24_7ServiceDesc": "Kun bo'yi sizning xizmatingizdamiz",
    
    // Cart and Products
    cart: "Savat",
    cartEmpty: "Savat bo'sh",
    add: "Qo'shish",
    addToCart: "Savatga qo'shish",
    addedToCart: "Savatga qo'shildi",
    addedToCartDesc: "savatga qo'shildi",
    quantity: "Miqdor",
    total: "Jami",
    currency: "so'm",
    checkout: "Buyurtma berish",
    placeOrder: "Buyurtma berish",
    placing: "Buyurtma berilmoqda...",
    
    // Order Process
    deliveryAddress: "Yetkazish manzili",
    enterAddress: "Manzilingizni kiriting",
    paymentMethod: "To'lov usuli",
    cash: "Naqd pul",
    card: "Plastik karta",
    back: "Orqaga",
    orderPlaced: "Buyurtma berildi",
    orderPlacedDesc: "Buyurtmangiz muvaffaqiyatli berildi",
    orderError: "Buyurtma berishda xatolik yuz berdi",
    addressRequired: "Manzil kiritish majburiy",
    
    // Authentication
    phoneNumber: "Telefon raqam",
    password: "Parol",
    enterPassword: "Parolingizni kiriting",
    noAccount: "Hisobingiz yo'qmi? Ro'yxatdan o'ting",
    sendSmsCode: "SMS kod yuborish",
    smsCode: "SMS kod",
    enterCode: "Kodni kiriting",
    verify: "Tasdiqlash",
    resendCode: "Kodni qayta yuborish",
    createPassword: "Parol yarating",
    confirmPassword: "Parolni tasdiqlang",
    reenterPassword: "Parolni qayta kiriting",
    createAccount: "Hisobni yaratish",
    
    // Auth Messages
    smsSent: "SMS yuborildi",
    verified: "Tasdiqlandi",
    registered: "Ro'yxatdan o'tdingiz",
    welcomeMessage: "Xush kelibsiz!",
    loggedIn: "Tizimga kirdingiz",
    welcomeBack: "Yana xush kelibsiz!",
    
    // Validation Messages
    phoneRequired: "Telefon raqam kiritish majburiy",
    codeRequired: "Kodni kiriting",
    passwordTooShort: "Parol kamida 8 ta belgidan iborat bo'lishi kerak",
    passwordsNotMatch: "Parollar mos kelmaydi",
    fillAllFields: "Barcha maydonlarni to'ldiring",
    invalidCode: "Noto'g'ri yoki muddati o'tgan kod",
    passwordMinLength: "Kamida 8 ta belgi",
    passwordRequirements: "Parol kamida 8 ta belgi, raqam va harf bo'lishi kerak",
    
    // Loading states
    sending: "Yuborilmoqda...",
    verifying: "Tekshirilmoqda...",
    creating: "Yaratilmoqda...",
    loggingIn: "Kirilmoqda...",
    
    // Product Modal
    leaveComment: "Sharh qoldiring",
    commentPlaceholder: "Bu taom haqida fikringizni yozing...",
    cancel: "Bekor qilish",
    customerComments: "Mijozlar sharhlari",
    commentAdded: "Sharh qo'shildi",
    commentAddedDesc: "Sharhingiz muvaffaqiyatli qo'shildi",
    
    // Footer
    brandDescription: "O'zbek milliy taomlarini eng tez va sifatli yetkazib berish xizmati",
    contactUs: "Biz bilan bog'lanish",
    socialNetworks: "Ijtimoiy tarmoqlar",
    allRightsReserved: "Barcha huquqlar himoyalangan",
    
    // General
    error: "Xatolik",
    success: "Muvaffaqiyat",
    noProductsAvailable: "Hozircha mahsulotlar mavjud emas",
    smsError: "SMS yuborishda xatolik",
    registrationError: "Ro'yxatdan o'tishda xatolik",
    loginError: "Tizimga kirishda xatolik"
  },
  
  ru: {
    // Navigation
    home: "Главная",
    products: "Продукты",
    news: "Новости",
    contact: "Контакты",
    login: "Войти",
    signup: "Регистрация",
    logout: "Выйти",
    hello: "Привет",
    
    // Homepage
    fastAndDelicious: "Быстро и Вкусно",
    uzbekNationalDishes: "Доставляем узбекские национальные блюда до вашего дома",
    orderNow: "Заказать",
    newTaste: "Новый Вкус",
    freshDailyMeals: "Каждый день готовим новые и качественные блюда",
    viewMore: "Посмотреть больше",
    in30Minutes: "За 30 Минут",
    deliveryPromise: "Доставляем все заказы в течение 30 минут",
    popularDishes: "Популярные Блюда",
    selectDeliciousDishes: "Выберите самые лучшие и вкусные блюда",
    
    // Features
    whyChooseUs: "Почему именно мы?",
    ourAdvantages: "Наши преимущества",
    fastDelivery: "Быстрая доставка",
    fastDeliveryDesc: "Доставляем до вашего дома за 30 минут",
    qualityFood: "Качественная еда",
    qualityFoodDesc: "Готовим только из свежих и качественных продуктов",
    "24_7Service": "Круглосуточный сервис",
    "24_7ServiceDesc": "Мы к вашим услугам круглые сутки",
    
    // Cart and Products
    cart: "Корзина",
    cartEmpty: "Корзина пуста",
    add: "Добавить",
    addToCart: "В корзину",
    addedToCart: "Добавлено в корзину",
    addedToCartDesc: "добавлено в корзину",
    quantity: "Количество",
    total: "Итого",
    currency: "сум",
    checkout: "Оформить заказ",
    placeOrder: "Оформить заказ",
    placing: "Оформляется...",
    
    // Order Process
    deliveryAddress: "Адрес доставки",
    enterAddress: "Введите ваш адрес",
    paymentMethod: "Способ оплаты",
    cash: "Наличные",
    card: "Банковская карта",
    back: "Назад",
    orderPlaced: "Заказ оформлен",
    orderPlacedDesc: "Ваш заказ успешно оформлен",
    orderError: "Ошибка при оформлении заказа",
    addressRequired: "Необходимо указать адрес",
    
    // Authentication
    phoneNumber: "Номер телефона",
    password: "Пароль",
    enterPassword: "Введите пароль",
    noAccount: "Нет аккаунта? Зарегистрируйтесь",
    sendSmsCode: "Отправить SMS код",
    smsCode: "SMS код",
    enterCode: "Введите код",
    verify: "Подтвердить",
    resendCode: "Отправить код повторно",
    createPassword: "Создайте пароль",
    confirmPassword: "Подтвердите пароль",
    reenterPassword: "Повторите пароль",
    createAccount: "Создать аккаунт",
    
    // Auth Messages
    smsSent: "SMS отправлен",
    verified: "Подтверждено",
    registered: "Регистрация завершена",
    welcomeMessage: "Добро пожаловать!",
    loggedIn: "Вы вошли в систему",
    welcomeBack: "С возвращением!",
    
    // Validation Messages
    phoneRequired: "Номер телефона обязателен",
    codeRequired: "Введите код",
    passwordTooShort: "Пароль должен содержать минимум 8 символов",
    passwordsNotMatch: "Пароли не совпадают",
    fillAllFields: "Заполните все поля",
    invalidCode: "Неверный или истекший код",
    passwordMinLength: "Минимум 8 символов",
    passwordRequirements: "Пароль должен содержать минимум 8 символов, цифры и буквы",
    
    // Loading states
    sending: "Отправляется...",
    verifying: "Проверяется...",
    creating: "Создается...",
    loggingIn: "Вход...",
    
    // Product Modal
    leaveComment: "Оставить отзыв",
    commentPlaceholder: "Напишите ваше мнение об этом блюде...",
    cancel: "Отмена",
    customerComments: "Отзывы клиентов",
    commentAdded: "Отзыв добавлен",
    commentAddedDesc: "Ваш отзыв успешно добавлен",
    
    // Footer
    brandDescription: "Сервис быстрой и качественной доставки узбекских национальных блюд",
    contactUs: "Связаться с нами",
    socialNetworks: "Социальные сети",
    allRightsReserved: "Все права защищены",
    
    // General
    error: "Ошибка",
    success: "Успех",
    noProductsAvailable: "Пока нет доступных продуктов",
    smsError: "Ошибка отправки SMS",
    registrationError: "Ошибка регистрации",
    loginError: "Ошибка входа в систему"
  },
  
  en: {
    // Navigation
    home: "Home",
    products: "Products",
    news: "News",
    contact: "Contact",
    login: "Login",
    signup: "Sign Up",
    logout: "Logout",
    hello: "Hello",
    
    // Homepage
    fastAndDelicious: "Fast and Delicious",
    uzbekNationalDishes: "We deliver Uzbek national dishes to your home",
    orderNow: "Order Now",
    newTaste: "New Taste",
    freshDailyMeals: "We prepare fresh and quality meals daily",
    viewMore: "View More",
    in30Minutes: "In 30 Minutes",
    deliveryPromise: "We deliver all orders within 30 minutes",
    popularDishes: "Popular Dishes",
    selectDeliciousDishes: "Choose our finest and most delicious dishes",
    
    // Features
    whyChooseUs: "Why choose us?",
    ourAdvantages: "Our advantages",
    fastDelivery: "Fast delivery",
    fastDeliveryDesc: "We deliver to your home within 30 minutes",
    qualityFood: "Quality food",
    qualityFoodDesc: "We prepare only from fresh and quality ingredients",
    "24_7Service": "24/7 service",
    "24_7ServiceDesc": "We are at your service around the clock",
    
    // Cart and Products
    cart: "Cart",
    cartEmpty: "Cart is empty",
    add: "Add",
    addToCart: "Add to Cart",
    addedToCart: "Added to cart",
    addedToCartDesc: "added to cart",
    quantity: "Quantity",
    total: "Total",
    currency: "sum",
    checkout: "Checkout",
    placeOrder: "Place Order",
    placing: "Placing order...",
    
    // Order Process
    deliveryAddress: "Delivery Address",
    enterAddress: "Enter your address",
    paymentMethod: "Payment Method",
    cash: "Cash",
    card: "Card",
    back: "Back",
    orderPlaced: "Order Placed",
    orderPlacedDesc: "Your order has been successfully placed",
    orderError: "Error placing order",
    addressRequired: "Address is required",
    
    // Authentication
    phoneNumber: "Phone Number",
    password: "Password",
    enterPassword: "Enter your password",
    noAccount: "Don't have an account? Sign up",
    sendSmsCode: "Send SMS Code",
    smsCode: "SMS Code",
    enterCode: "Enter code",
    verify: "Verify",
    resendCode: "Resend code",
    createPassword: "Create Password",
    confirmPassword: "Confirm Password",
    reenterPassword: "Re-enter password",
    createAccount: "Create Account",
    
    // Auth Messages
    smsSent: "SMS sent",
    verified: "Verified",
    registered: "Registered",
    welcomeMessage: "Welcome!",
    loggedIn: "Logged in",
    welcomeBack: "Welcome back!",
    
    // Validation Messages
    phoneRequired: "Phone number is required",
    codeRequired: "Please enter the code",
    passwordTooShort: "Password must be at least 8 characters",
    passwordsNotMatch: "Passwords do not match",
    fillAllFields: "Please fill all fields",
    invalidCode: "Invalid or expired code",
    passwordMinLength: "At least 8 characters",
    passwordRequirements: "Password must contain at least 8 characters, numbers and letters",
    
    // Loading states
    sending: "Sending...",
    verifying: "Verifying...",
    creating: "Creating...",
    loggingIn: "Logging in...",
    
    // Product Modal
    leaveComment: "Leave a comment",
    commentPlaceholder: "Write your opinion about this dish...",
    cancel: "Cancel",
    customerComments: "Customer Comments",
    commentAdded: "Comment added",
    commentAddedDesc: "Your comment has been successfully added",
    
    // Footer
    brandDescription: "Fast and quality delivery service for Uzbek national dishes",
    contactUs: "Contact Us",
    socialNetworks: "Social Networks",
    allRightsReserved: "All rights reserved",
    
    // General
    error: "Error",
    success: "Success",
    noProductsAvailable: "No products available at the moment",
    smsError: "SMS sending error",
    registrationError: "Registration error",
    loginError: "Login error"
  }
};

export type Language = keyof typeof translations;
export type TranslationKey = keyof typeof translations.uz;
