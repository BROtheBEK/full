import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";

export default function Admin() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedSection, setSelectedSection] = useState("products");
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [selectedRole, setSelectedRole] = useState<string>("");

  const { data: products = [] } = useQuery({
    queryKey: ["/api/products"],
    enabled: user?.role === "admin",
  });

  const { data: orders = [] } = useQuery({
    queryKey: ["/api/orders"],
    enabled: user?.role === "admin",
  });

  const createProductMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/products", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({ title: "Mahsulot qo'shildi", description: "Yangi mahsulot muvaffaqiyatli qo'shildi" });
    },
    onError: () => {
      toast({ title: "Xatolik", description: "Mahsulot qo'shishda xatolik yuz berdi", variant: "destructive" });
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      return apiRequest("PUT", `/api/products/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({ title: "Tahrirlandi", description: "Mahsulot muvaffaqiyatli tahrirlandi" });
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/products/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({ title: "O'chirildi", description: "Mahsulot muvaffaqiyatli o'chirildi" });
    },
  });

  const createNewsMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/news", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/news"] });
      toast({ title: "Yangilik qo'shildi", description: "Yangi yangilik muvaffaqiyatli qo'shildi" });
    },
    onError: () => {
      toast({ title: "Xatolik", description: "Yangilik qo'shishda xatolik yuz berdi", variant: "destructive" });
    },
  });

  const deleteNewsMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/news/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/news"] });
      toast({ title: "O'chirildi", description: "Yangilik muvaffaqiyatli o'chirildi" });
    },
  });

  const createUserMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/admin/users", data);
    },
    onSuccess: () => {
      toast({ title: "Foydalanuvchi yaratildi", description: "Yangi foydalanuvchi muvaffaqiyatli yaratildi" });
    },
  });

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <h1 className="text-2xl font-bold mb-4">Ruxsat berilmagan</h1>
              <p className="text-neutral-600 mb-4">Bu sahifaga kirish uchun admin huquqlari kerak</p>
              <Link href="/">
                <Button>Bosh sahifaga qaytish</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-xl font-semibold text-neutral-900">Admin Panel</h1>
            <div className="flex items-center space-x-4">
              <span className="text-neutral-600">Salom, {user?.firstName || user?.phone}</span>
              <Link href="/">
                <Button variant="outline">Saytga qaytish</Button>
              </Link>
              <Button variant="ghost" onClick={logout}>Chiqish</Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={selectedSection} onValueChange={setSelectedSection}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="products">Mahsulotlar</TabsTrigger>
            <TabsTrigger value="news">Yangiliklar</TabsTrigger>
            <TabsTrigger value="delivery">Yetkazuvchilar</TabsTrigger>
            <TabsTrigger value="analytics">Hisobotlar</TabsTrigger>
          </TabsList>

          <TabsContent value="products" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Mahsulotlar boshqaruvi</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-secondary hover:bg-green-600">
                    <i className="fas fa-plus mr-2"></i>Yangi mahsulot
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Yangi mahsulot qo'shish</DialogTitle>
                  </DialogHeader>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      const data = {
                        name: formData.get("name"),
                        description: formData.get("description"),
                        price: formData.get("price"),
                        images: formData.get("images")?.toString().split(",").map(url => url.trim()) || [],
                      };
                      createProductMutation.mutate(data);
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <Label htmlFor="name">Nomi</Label>
                      <Input id="name" name="name" required />
                    </div>
                    <div>
                      <Label htmlFor="description">Tavsif</Label>
                      <Textarea id="description" name="description" required />
                    </div>
                    <div>
                      <Label htmlFor="price">Narx (so'm)</Label>
                      <Input id="price" name="price" type="number" required />
                    </div>
                    <div>
                      <Label htmlFor="images">Rasmlar URL (vergul bilan ajrating)</Label>
                      <Textarea id="images" name="images" placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg" />
                    </div>
                    <Button type="submit" disabled={createProductMutation.isPending}>
                      {createProductMutation.isPending ? "Qo'shilmoqda..." : "Qo'shish"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {products.map((product: any) => (
                <Card key={product.id}>
                  <CardContent className="flex items-center justify-between p-6">
                    <div className="flex items-center space-x-4">
                      {product.images?.[0] && (
                        <img 
                          src={product.images[0]} 
                          alt={product.name}
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                      )}
                      <div>
                        <h3 className="font-semibold">{product.name}</h3>
                        <p className="text-neutral-600">{product.price} so'm</p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => setEditingProduct(product)}
                      >
                        Tahrirlash
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        onClick={() => deleteProductMutation.mutate(product.id)}
                      >
                        O'chirish
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Edit Product Modal */}
            {editingProduct && (
              <Dialog open={!!editingProduct} onOpenChange={() => setEditingProduct(null)}>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Mahsulotni tahrirlash</DialogTitle>
                  </DialogHeader>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      const data = {
                        name: formData.get("name"),
                        description: formData.get("description"),
                        price: formData.get("price"),
                        images: formData.get("images")?.toString().split(",").map(url => url.trim()) || [],
                      };
                      updateProductMutation.mutate({ id: editingProduct.id, data });
                      setEditingProduct(null);
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <Label htmlFor="edit-name">Nomi</Label>
                      <Input id="edit-name" name="name" defaultValue={editingProduct.name} required />
                    </div>
                    <div>
                      <Label htmlFor="edit-description">Tavsif</Label>
                      <Textarea id="edit-description" name="description" defaultValue={editingProduct.description} required />
                    </div>
                    <div>
                      <Label htmlFor="edit-price">Narx (so'm)</Label>
                      <Input id="edit-price" name="price" type="number" defaultValue={editingProduct.price} required />
                    </div>
                    <div>
                      <Label htmlFor="edit-images">Rasmlar URL (vergul bilan ajrating)</Label>
                      <Textarea 
                        id="edit-images" 
                        name="images" 
                        defaultValue={editingProduct.images?.join(", ") || ""} 
                        placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg" 
                      />
                    </div>
                    <div className="flex space-x-2">
                      <Button type="button" variant="outline" onClick={() => setEditingProduct(null)}>
                        Bekor qilish
                      </Button>
                      <Button type="submit" disabled={updateProductMutation.isPending}>
                        {updateProductMutation.isPending ? "Saqlanmoqda..." : "Saqlash"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </TabsContent>

          <TabsContent value="news" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Yangiliklar boshqaruvi</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-blue-700">
                    <i className="fas fa-plus mr-2"></i>Yangilik qo'shish
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Yangi yangilik qo'shish</DialogTitle>
                  </DialogHeader>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      const data = {
                        title: formData.get("title"),
                        content: formData.get("content"),
                        image: formData.get("image"),
                      };
                      createNewsMutation.mutate(data);
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <Label htmlFor="title">Sarlavha</Label>
                      <Input id="title" name="title" required />
                    </div>
                    <div>
                      <Label htmlFor="content">Mazmun</Label>
                      <Textarea id="content" name="content" required />
                    </div>
                    <div>
                      <Label htmlFor="image">Rasm URL</Label>
                      <Input id="image" name="image" />
                    </div>
                    <Button type="submit" disabled={createNewsMutation.isPending}>
                      {createNewsMutation.isPending ? "Qo'shilmoqda..." : "Qo'shish"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </TabsContent>

          <TabsContent value="delivery" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Yetkazuvchilar boshqaruvi</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-secondary hover:bg-green-600">
                    <i className="fas fa-plus mr-2"></i>Yetkazuvchi qo'shish
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Yangi yetkazuvchi qo'shish</DialogTitle>
                  </DialogHeader>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      const data = {
                        firstName: formData.get("firstName"),
                        lastName: formData.get("lastName"),
                        phone: formData.get("phone"),
                        password: formData.get("password"),
                        birthYear: parseInt(formData.get("birthYear") as string),
                        role: selectedRole,
                      };
                      createUserMutation.mutate(data);
                      setSelectedRole("");
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <Label htmlFor="firstName">Ism</Label>
                      <Input id="firstName" name="firstName" required />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Familiya</Label>
                      <Input id="lastName" name="lastName" required />
                    </div>
                    <div>
                      <Label htmlFor="phone">Telefon raqam</Label>
                      <Input id="phone" name="phone" required />
                    </div>
                    <div>
                      <Label htmlFor="password">Parol</Label>
                      <Input id="password" name="password" type="password" required />
                    </div>
                    <div>
                      <Label htmlFor="birthYear">Tug'ilgan yil</Label>
                      <Input id="birthYear" name="birthYear" type="number" />
                    </div>
                    <div>
                      <Label htmlFor="role">Rol</Label>
                      <Select value={selectedRole} onValueChange={setSelectedRole}>
                        <SelectTrigger>
                          <SelectValue placeholder="Rolni tanlang" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="delivery">Yetkazuvchi</SelectItem>
                          <SelectItem value="operator">Operator</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button type="submit" disabled={createUserMutation.isPending}>
                      {createUserMutation.isPending ? "Qo'shilmoqda..." : "Qo'shish"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <h2 className="text-2xl font-bold">Hisobotlar va statistika</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Jami buyurtmalar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-primary">{orders.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Jami mahsulotlar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-secondary">{products.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Yangi buyurtmalar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-accent">
                    {orders.filter((order: any) => order.status === "pending").length}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
