import axios from 'axios';

interface EskizTokenResponse {
  message: string;
  data: {
    token: string;
  };
}

interface EskizSmsResponse {
  status: string;
  message: string;
}

class EskizSMS {
  private token: string | null = null;
  private readonly baseUrl = 'https://notify.eskiz.uz/api';
  private readonly email: string;
  private readonly password: string;

  constructor() {
    this.email = process.env.ESKIZ_EMAIL || '';
    this.password = process.env.ESKIZ_PASSWORD || '';
  }

  private async getToken(): Promise<string> {
    if (this.token) {
      return this.token;
    }

    try {
      const response = await axios.post<EskizTokenResponse>(`${this.baseUrl}/auth/login`, {
        email: this.email,
        password: this.password,
      });

      this.token = response.data.data.token;
      return this.token;
    } catch (error) {
      console.error('Eskiz token olishda xato:', error);
      throw new Error('SMS xizmatiga ulanishda muammo');
    }
  }

  async sendSMS(phone: string, message: string): Promise<boolean> {
    try {
      const token = await this.getToken();

      // Telefon raqamini formatla (+ belgisini olib tashlash)
      const formattedPhone = phone.replace(/^\+/, '');

      const response = await axios.post<EskizSmsResponse>(
        `${this.baseUrl}/message/sms/send`,
        {
          mobile_phone: formattedPhone,
          message: message,
          from: '4546',  // Eskiz.uz standart qisqa raqami
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      return response.data.status === 'success';
    } catch (error) {
      console.error('SMS yuborishda xato:', error);
      
      // Token muammosi bo'lsa, tokenni tozala va qayta urining
      if (axios.isAxiosError(error) && error.response?.status === 401) {
        this.token = null;
        return this.sendSMS(phone, message);
      }
      
      return false;
    }
  }
}

export const eskizSMS = new EskizSMS();