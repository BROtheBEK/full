import { 
  users, 
  products, 
  orders, 
  news, 
  comments, 
  smsVerifications,
  type User, 
  type InsertUser,
  type Product,
  type InsertProduct,
  type Order,
  type InsertOrder,
  type News,
  type InsertNews,
  type Comment,
  type InsertComment,
  type SmsVerification,
  type InsertSmsVerification
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;

  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // Orders
  getOrders(): Promise<Order[]>;
  getOrdersByUser(userId: number): Promise<Order[]>;
  getOrdersByStatus(status: string): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: Partial<InsertOrder>): Promise<Order | undefined>;

  // News
  getNews(): Promise<News[]>;
  createNews(news: InsertNews): Promise<News>;
  updateNews(id: number, news: Partial<InsertNews>): Promise<News | undefined>;
  deleteNews(id: number): Promise<boolean>;

  // Comments
  getCommentsByProduct(productId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;

  // SMS Verifications
  createSmsVerification(sms: InsertSmsVerification): Promise<SmsVerification>;
  getSmsVerification(phone: string, code: string): Promise<SmsVerification | undefined>;
  updateSmsVerification(id: number, sms: Partial<InsertSmsVerification>): Promise<SmsVerification | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.phone, phone));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, insertUser: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(insertUser)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getProducts(): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.isActive, true)).orderBy(desc(products.createdAt));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db
      .insert(products)
      .values(insertProduct)
      .returning();
    return product;
  }

  async updateProduct(id: number, insertProduct: Partial<InsertProduct>): Promise<Product | undefined> {
    const [product] = await db
      .update(products)
      .set(insertProduct)
      .where(eq(products.id, id))
      .returning();
    return product || undefined;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db
      .update(products)
      .set({ isActive: false })
      .where(eq(products.id, id));
    return result.rowCount! > 0;
  }

  async getOrders(): Promise<Order[]> {
    return await db.select().from(orders).orderBy(desc(orders.createdAt));
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    return await db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
  }

  async getOrdersByStatus(status: string): Promise<Order[]> {
    return await db.select().from(orders).where(eq(orders.status, status)).orderBy(desc(orders.createdAt));
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order || undefined;
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db
      .insert(orders)
      .values(insertOrder)
      .returning();
    return order;
  }

  async updateOrder(id: number, insertOrder: Partial<InsertOrder>): Promise<Order | undefined> {
    const [order] = await db
      .update(orders)
      .set({ ...insertOrder, updatedAt: new Date() })
      .where(eq(orders.id, id))
      .returning();
    return order || undefined;
  }

  async getNews(): Promise<News[]> {
    return await db.select().from(news).where(eq(news.isActive, true)).orderBy(desc(news.createdAt));
  }

  async createNews(insertNews: InsertNews): Promise<News> {
    const [newsItem] = await db
      .insert(news)
      .values(insertNews)
      .returning();
    return newsItem;
  }

  async updateNews(id: number, insertNews: Partial<InsertNews>): Promise<News | undefined> {
    const [newsItem] = await db
      .update(news)
      .set(insertNews)
      .where(eq(news.id, id))
      .returning();
    return newsItem || undefined;
  }

  async deleteNews(id: number): Promise<boolean> {
    const result = await db
      .update(news)
      .set({ isActive: false })
      .where(eq(news.id, id));
    return result.rowCount! > 0;
  }

  async getCommentsByProduct(productId: number): Promise<Comment[]> {
    return await db.select().from(comments).where(eq(comments.productId, productId)).orderBy(desc(comments.createdAt));
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const [comment] = await db
      .insert(comments)
      .values(insertComment)
      .returning();
    return comment;
  }

  async createSmsVerification(insertSms: InsertSmsVerification): Promise<SmsVerification> {
    const [sms] = await db
      .insert(smsVerifications)
      .values(insertSms)
      .returning();
    return sms;
  }

  async getSmsVerification(phone: string, code: string): Promise<SmsVerification | undefined> {
    if (!code) {
      // Agar kod bo'sh bo'lsa, eng so'nggi SMS ni qaytarish (limit tekshirish uchun)
      const [sms] = await db
        .select()
        .from(smsVerifications)
        .where(eq(smsVerifications.phone, phone))
        .orderBy(desc(smsVerifications.createdAt))
        .limit(1);
      return sms || undefined;
    }
    
    const [sms] = await db
      .select()
      .from(smsVerifications)
      .where(and(eq(smsVerifications.phone, phone), eq(smsVerifications.code, code)));
    return sms || undefined;
  }

  async updateSmsVerification(id: number, insertSms: Partial<InsertSmsVerification>): Promise<SmsVerification | undefined> {
    const [sms] = await db
      .update(smsVerifications)
      .set(insertSms)
      .where(eq(smsVerifications.id, id))
      .returning();
    return sms || undefined;
  }
}

export const storage = new DatabaseStorage();
